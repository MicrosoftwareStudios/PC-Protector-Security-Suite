#! /bin/bash
echo
echo PC Protector Security Suite Installer
echo -------------------------------------
echo
read -p "Press ENTER to install this software..." notneeded
clear
echo
echo PC Protector Security Suite Installer
echo -------------------------------------
echo
echo "+-------------------------------------+"
echo "| PC Protector Security Suite EULA    |"
echo "|  (c) Microsoftware 2022             |"
echo "| 1. Do not distribute this software  |"
echo "|     illegally                       |"
echo "| 2. Do not copy any part of this     |"
echo "|     software                        |"
echo "| 3. Do not modify any part of this   |"
echo "|     software                        |"
echo "+-------------------------------------+"
echo
read -p "Press 1 to agree to this EULA, 2 to disagree..." eula
if [ $eula == 1 ]; then
clear
echo
echo PC Protector Security Suite Installer
echo -------------------------------------
echo
read -p "Press ENTER to start installation..." bluah
clear
echo
echo PC Protector Security Suite Installer
echo -------------------------------------
echo
echo Updating system...
sudo apt-get update
sudo apt-get full-upgrade
clear
echo
echo PC Protector Security Suite Installer
echo -------------------------------------
echo
echo Updating system...
echo Done.
echo
echo Preparing for installation...
cd ~/Desktop
sudo mkdir antivirus
cd ~/Desktop/antivirus
echo Done.
echo
echo Downloading files...
sudo wget http://192.168.0.153/downloads/antivirus.zip
sudo unzip antivirus.zip

echo
echo PC Protector Security Suite Installer
echo -------------------------------------
echo
echo Updating system...
echo Done.
echo
echo Preparing for installation...
echo Done.
echo
echo Downloading files...
echo Done.
echo
echo Setting up program...
sudo rm antivirus.zip
sudo chmod +x *
sudo chown andrew *
sudo cp alacarte-made-6.desktop ~/Desktop
clear
echo
echo PC Protector Security Suite Installer
echo -------------------------------------
echo
echo Installation complete! Setup will now launch the program.
read -p "Press ENTER to continue..." blah
clear
~/Desktop/antivirus/home.sh
else
exit
fi
